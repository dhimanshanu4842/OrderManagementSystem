﻿using Microsoft.AspNetCore.Identity;

namespace OrderManagementSystem.Models
{
    public class User:IdentityUser
    {
       
    }
}
